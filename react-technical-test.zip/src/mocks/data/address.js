let address = [
  {
    id: "286206f8-2e69-4dcd-b79b-700a683cd931",
    street: "Av. Rivadavia",
    postalCode: 4000,
    city: "San Miguel de Tucumán",
    province: "Tucumán",
    country: "Argentina",
  },
  {
    id: "ed9b39a5-5d28-4e2d-b7da-b277e3e6e7bd",
    street: "Av. Sarmiento",
    postalCode: 4000,
    city: "San Miguel de Tucumán",
    province: "Tucumán",
    country: "Argentina",
  },
  {
    id: "d8cf0efa-5789-4540-934f-13697955afb7",
    street: "Av. Belgrano",
    postalCode: 94000,
    city: "San Miguel de Tucumán",
    province: "Tucumán",
    country: "Argentina",
  },
  {
    id: "20929e58-8681-4fb8-ba3a-b0f013bbb776",
    street: "Av. Alem",
    postalCode: 4000,
    city: "San Miguel de Tucumán",
    province: "Tucumán",
    country: "Argentina",
  },
  {
    id: "f8c1e2b4-3d5a-4f0b-9c7e-3d5a4f0b9c7e",
    street: "Av. Perón",
    postalCode: 4107,
    city: "Yerba Buena",
    province: "Tucumán",
    country: "Argentina",
  },
  {
    id: "68e3a787-19a0-4070-99ed-e8cd7ca04146",
    street: "Av. Aconquija",
    postalCode: 4107,
    city: "Yerba Buena",
    province: "Tucumán",
    country: "Argentina",
  },
];

export default address;
