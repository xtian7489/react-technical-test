let users = [
  {
    id: "21186f91-d99f-4f4f-a163-c0e116f9f8fa",
    email: "admin@site.com",
    password: "$2b$10$NwjWaWQ0lSSP2PKs4WjFgePtRNzozEGCtfKQXrcyi.HY1y3yNIF7a", //123456
    role: "admin",
    studies: [],
    address: "",
  },
  {
    id: "21186f91-d99f-4f4f-a163-c0e116f9f7fa",
    email: "user@site.com",
    password: "$2b$10$NwjWaWQ0lSSP2PKs4WjFgePtRNzozEGCtfKQXrcyi.HY1y3yNIF7a", //123456
    role: "user",
    studies: [
      "425276e9-9f0a-4a3d-bf71-fe30ac0ae85d",
      "f26c233f-cde5-40d1-97ad-da9205a0e2a0",
    ],
    address: "20929e58-8681-4fb8-ba3a-b0f013bbb776",
  },
];

export default users;
