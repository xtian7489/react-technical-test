import Home from "../components/home";

const Dashboard = () => {
  return <Home />;
};

export default Dashboard;
